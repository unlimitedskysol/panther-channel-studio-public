PANTHER CHANNEL STUDIO
V7.0.16

Official website:
https://studio.panthergame.app/

Run PANTHER_CHANNEL_STUDIO_V7_0_16.exe.
Windows 10/11 x64.

This public package contains no application source code.
The executable is currently unsigned, so Windows or the browser may show an unknown/suspicious publisher warning. Verify the SHA-256 before running it.
